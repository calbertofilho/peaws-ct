#!/bin/bash
cp -R /home/ubuntu/app/* /var/www/html/   