#!/bin/bash
systemctl start apache2.service
systemctl enable apache2.service